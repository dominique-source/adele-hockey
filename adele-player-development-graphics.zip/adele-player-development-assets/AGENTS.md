# Instructions Codex — ADÈLE | PLAYER DEVELOPMENT

## Objectif
Construire une web app responsive mobile-first **aussi fidèle que possible** aux maquettes de `references/screens/`. Conserver le style premium : thème noir/charbon, cyan et lime électrique, hockey féminin dynamique, grandes photos cinématiques, typographie sportive condensée, cartes arrondies, navigation basse.

## Références
- Accueil cible : `02-accueil-own-your-game.png`
- Programme détaillé : `03-programme-seances-detaillees.png`
- Exercices : `04-bibliotheque-exercices.png`
- Fiche exercice : `05-fiche-exercice-edge-control.png`
- Analyse vidéo : `06-analyse-video-comparaison.png`
- Session active : `07-session-active.png`
- Progression : `08-progression-statistiques.png`
- Variantes : `01`, `09`, `10` (ne pas substituer sans raison)

## Fonctionnalités
1. Navigation : Accueil, Programme, Exercices, Progression, Analyse.
2. 4 axes : Patin, Maniement de rondelle, Lancer, Décision 1 vs 1.
3. Programme : 2 séances de 30 minutes par semaine, focus, intensité, engagement.
4. Exercices : image/vidéo de référence, explication, points techniques, erreurs à éviter, progressions.
5. Séance active : chronomètre, progression par blocs, boutons pause/reprise/terminer, notes.
6. Analyse : ajout de vidéo, lecture ralentie, comparaison côte à côte, annotations (si réalisable dans le périmètre), suivi des évaluations.
7. Progression : graphiques et historiques basés sur de vraies données saisies, jamais des métriques de démonstration présentées comme réelles.
8. Prévoir deux rôles : parent/entraîneur et Adèle, dans un espace privé.

## Fidélité et validation
- Toujours comparer la capture de l'implémentation à l'image de référence correspondante, aux tailles mobiles.
- Respecter hiérarchie, proportions, espacements, tailles de texte, couleurs, formes et position des éléments.
- Ne pas insérer de fausses vidéos actives ni de statistiques réelles inventées.
- Ne pas embarquer les captures de maquette comme interface entière : elles ne sont pas cliquables.
- Réutiliser les références originales dans la documentation et les tests visuels.
- Ne pas tenter d'extraire des polices propriétaires; choisir des alternatives légales.
- Toutes les vues fonctionnent au tactile et restent utilisables sur écran étroit.
- Si les vraies photos isolées manquent, marquer les assets photo comme à produire/remplacer au lieu de promettre une copie exacte.

## Traitement des images
Les dix PNG sont dans `references/screens`. Ce sont des éléments de référence, non une banque complète d'assets indépendants. Prévoir un dossier `public/assets/` pour les futurs portraits, arrière-plans, pictogrammes et miniatures, sans confondre avec les PNG de référence.
