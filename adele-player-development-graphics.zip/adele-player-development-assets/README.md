# ADÈLE | Player Development — Pack de références visuelles

Ce dépôt contient **les 10 PNG originaux de maquettes générées dans la conversation**, sans retouche, et un guide pour leur reproduction dans une application web mobile-first.

## Organisation

- `references/screens/` : maquettes PNG originales, numérotées dans l’ordre de conception.
- `references/contact-sheet.jpg` : aperçu de toutes les maquettes.
- `screens-manifest.json` : dimensions, rôles et SHA-256 des fichiers.
- `design-tokens.json` : proposition de couleurs et de langage visuel (valeurs approximatives).
- `AGENTS.md` : directives pour Codex lors de la construction.

## Écrans principaux

01 Accueil initial (concept)
02 Accueil « Own Your Game »
03 Programme détaillé avec séances A et B
04 Bibliothèque d’exercices
05 Fiche technique d’exercice
06 Analyse vidéo avant / après
07 Séance active / minuterie
08 Tableau de progression
09 Programme / calendrier (variante)
10 Tableau de bord « Mon parcours » (variante, format plus large)

## Important — fidélité visuelle

Les PNG sont des **images aplaties**, pas des fichiers Figma, ni des calques, ni des composants UI, ni des photos sources isolées. Les boutons et lecteurs visibles dans les maquettes ne sont pas fonctionnels. On peut recréer une interface très proche, mais une correspondance pixel par pixel ne peut pas être garantie sans reconstruire et ajuster les composants, trouver/produire les photos séparément, et valider les rendus à l'écran.

Le numéro 02 sert de direction principale pour l'accueil; 03, 04, 05, 06, 07 et 08 sont les vues fonctionnelles principales; 01, 09 et 10 servent de variantes complémentaires. **Ne pas mélanger leurs dispositions sans décision explicite.**

Ne pas utiliser une capture complète comme unique interface interactive : reconstruire les contrôles en composants accessibles et responsives. Les captures restent des références visuelles.

## Contenus & droits

Les photos intégrées aux maquettes sont des images générées dans les rendus; elles ne sont pas fournies séparément. Il faudra créer des visuels cohérents ou obtenir des visuels licenciés, en respectant une représentation diversifiée des athlètes. La personne représentée dans les maquettes est un personnage illustratif, non une photo vérifiée d'Adèle. Le numéro 22 et les statistiques affichées sont des éléments fictifs de design à remplacer/confirmer.
